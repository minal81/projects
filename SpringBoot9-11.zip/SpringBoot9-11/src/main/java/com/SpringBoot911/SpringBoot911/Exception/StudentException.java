package com.SpringBoot911.SpringBoot911.Exception;

public class StudentException extends RuntimeException{

		private static final long serialVersionUID = -1456085123389742455L;

	public StudentException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
