package com.SpringBoot911.SpringBoot911;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBoot911Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot911Application.class, args);
	}

}
