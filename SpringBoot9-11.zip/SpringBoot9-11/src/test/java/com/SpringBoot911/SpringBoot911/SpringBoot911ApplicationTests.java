package com.SpringBoot911.SpringBoot911;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBoot911ApplicationTests {

	@Test
	void contextLoads() {
	}

}
