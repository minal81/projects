package com.CakeLover;

public class CakeMain {
	public static void  main(String arg[]) {

	CakeOrderLogic Cakewow = new CakeOrderLogic();
	Cakewow.AddCake();
	
	}}
